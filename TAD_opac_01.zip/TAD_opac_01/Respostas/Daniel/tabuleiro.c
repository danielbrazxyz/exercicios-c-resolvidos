#include <stdio.h>
#include <stdlib.h>
#include "tabuleiro.h"

struct Tabuleiro
{
          char peca1,peca2,peca_vazio;
          int **posicao;
};

/**
 * Aloca e retorna uma estrutura do tipo tTabuleiro.
 * Se a alocação falhar, o programa é encerrado.
 * 
 * @return a estrutura do tipo tTabuleiro alocada.
 */
tTabuleiro* CriaTabuleiro(){
    tTabuleiro *tabuleiro = (tTabuleiro*)malloc(sizeof(struct Tabuleiro));
    if(tabuleiro == NULL){
          exit(1);
    }
    tabuleiro->posicao = (int)malloc(sizeof(int)*TAM_TABULEIRO);
     if(tabuleiro->posicao == NULL){
          exit(1);
    }

    for(int i = 0 ; i < TAM_TABULEIRO;i++){
          tabuleiro->posicao[i] = (int)malloc(sizeof(int)*TAM_TABULEIRO);
    }
     if(tabuleiro->posicao == NULL){
          exit(1);
    }
 }


/**
 * Libera a memória de uma estrutura do tipo tTabuleiro.
 * 
 * @param tabuleiro a estrutura do tipo tTabuleiro a ser liberada.
 */
void DestroiTabuleiro(tTabuleiro* tabuleiro){
          for(int i = 0 ; i < TAM_TABULEIRO; i++){
                    free(tabuleiro->posicao[i]);
          }
          free(tabuleiro->posicao);
          free(tabuleiro);
}


/**
 * Marca uma posição do tabuleiro com a peça do jogador.
 * 
 * @param tabuleiro o tabuleiro atual.
 * @param peca a peça do jogador (1 ou 2).
 * @param x a coordenada X da posição.
 * @param y a coordenada Y da posição.
 */
void MarcaPosicaoTabuleiro(tTabuleiro* tabuleiro, int peca, int x, int y){
          if(peca == PECA_1){
                    tabuleiro->posicao[x][y]= tabuleiro->peca1;
          }
          if(peca == PECA_2){
                    tabuleiro->posicao[x][y]= tabuleiro->peca2;
          }
}


/**
 * Verifica se há alguma posição livre no tabuleiro.
 * 
 * @param tabuleiro o tabuleiro atual.
 * 
 * @return 1 se há alguma posição livre, 0 caso contrário.
 */
int TemPosicaoLivreTabuleiro(tTabuleiro* tabuleiro){
          for(int i = 0 ; i < TAM_TABULEIRO ; i++){
                    for(int j = 0 ; j < TAM_TABULEIRO; j++){
                              if((tabuleiro->posicao[i][j]) == tabuleiro->peca_vazio){
                                        return 1;
                              };
                    }
          }
          return 0;
}


/**
 * Verifica se a posição do tabuleiro está marcada com a peça do jogador.
 * 
 * @param tabuleiro - o tabuleiro atual.
 * @param x a coordenada X da posição.
 * @param y a coordenada Y da posição.
 * @param peca a peça do jogador (1 ou 2).
 * 
 * @return 1 se a posição está marcada com a peça do jogador, 0 caso contrário.
 */
int EstaMarcadaPosicaoPecaTabuleiro(tTabuleiro* tabuleiro, int x, int y, int peca){
          if(peca == PECA_1){
           if (tabuleiro->posicao[x][y] == tabuleiro->peca1){
                    return 1;
           }
          }
           if(peca == PECA_2){
           if (tabuleiro->posicao[x][y] == tabuleiro->peca2){
                    return 1;
           }
          }
          return 0;
          
}


/**
 * Verifica se a posição do tabuleiro está livre.
 * 
 * @param tabuleiro o tabuleiro atual.
 * @param x a coordenada X da posição.
 * @param y a coordenada Y da posição.
 * 
 * @return 1 se a posição está livre, 0 caso contrário.
 */
int EstaLivrePosicaoTabuleiro(tTabuleiro* tabuleiro, int x, int y){
          if(tabuleiro->posicao[x][y]== tabuleiro->peca_vazio){
                    return 1;
          }
          return 0;
}


/**
 * Verifica se a posição do tabuleiro é válida.
 * 
 * @param x a coordenada X da posição.
 * @param y a coordenada Y da posição.
 * 
 * @return 1 se a posição é válida, 0 caso contrário.
 */
int EhPosicaoValidaTabuleiro(int x, int y){
          if((x >= 0 && x < TAM_TABULEIRO)&& (y >= 0 && y < TAM_TABULEIRO)){
                    return 1;
          }
          return 0;
}


/**
 * Imprime o tabuleiro.
 * 
 * @param tabuleiro o tabuleiro atual.
 */
void ImprimeTabuleiro(tTabuleiro* tabuleiro){
for(int i = 0 ; i < TAM_TABULEIRO ; i++){
          printf("\t");
                    for(int j = 0 ; j < TAM_TABULEIRO; j++){
                                        printf("%d",tabuleiro->posicao[i][j]);
                              };
                    }printf("\n");
          }

