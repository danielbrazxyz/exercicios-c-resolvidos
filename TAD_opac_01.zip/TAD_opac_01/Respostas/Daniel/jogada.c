#include <stdio.h>
#include <stdlib.h>
#include "jogada.h"

struct Jogada{
    int sucesso;
    int pos_x,pos_y;
};


/**
 * Aloca e retorna uma estrutura do tipo tJogada.
 * Se a alocação falhar, o programa é encerrado.
 * 
 * @return a estrutura do tipo tJogada alocada.
 */
tJogada* CriaJogada(){
          tJogada *jogada = (tJogada*)malloc(sizeof(struct Jogada));
          if(jogada == NULL){
           exit(1);
          }
         jogada->sucesso = 0;
         return jogada;
}


/**
 * Libera a memória de uma estrutura do tipo tJogada.
 * 
 * @param jogada a estrutura do tipo tJogada a ser liberada.
 */
void DestroiJogada(tJogada* jogada){
          free(jogada);
}


/**
 * Solicita ao usuário as coordenadas de uma jogada,
 * realiza a leitura e armazena os valores em uma estrutura do tipo tJogada.
 * 
 * @param jogada a estrutura do tipo tJogada a ser preenchida.
 */
void LeJogada(tJogada* jogada){
          printf("Digite uma posicao (x e y):\n");
          if(scanf("%d %d",&jogada->pos_x,&jogada->pos_y)==2){
                    jogada->sucesso = 1;
          }
}


/**
 * Retorna a coordenada X da jogada.
 * 
 * @param jogada a estrutura do tipo tJogada.
 * 
 * @return a coordenada X da jogada.
 */
int ObtemJogadaX(tJogada* jogada){
          return jogada->pos_x;
}

/**
 * Retorna a coordenada Y da jogada.
 * 
 * @param jogada a estrutura do tipo tJogada.
 * 
 * @return a coordenada Y da jogada.
 */
int ObtemJogadaY(tJogada* jogada){
          return jogada->pos_y;
}


/**
 * Retorna 1 se a jogada foi bem sucedida e 0 caso contrário.
 * 
 * @param jogada a estrutura do tipo tJogada.
 * 
 * @return 1 se a jogada foi bem sucedida, 0 caso contrário.
 */
int FoiJogadaBemSucedida(tJogada* jogada){
          return jogada->sucesso;
}
