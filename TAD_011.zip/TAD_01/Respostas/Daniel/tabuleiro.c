#include <stdio.h>
#include "tabuleiro.h"

/**
 * Cria um tabuleiro e retorna o tabuleiro criado.
 */
tTabuleiro CriaTabuleiro()
{
    tTabuleiro tabuleiro;
    tabuleiro.pecaVazio = '-';
    tabuleiro.peca1 = 'X';
    tabuleiro.peca2 = '0';

    for (int i = 0; i < TAM_TABULEIRO; i++)
    {
        for (int j = 0; j < TAM_TABULEIRO; j++)
        {
            tabuleiro.posicoes[i][j] = tabuleiro.pecaVazio;
        }
    }
    return tabuleiro;
}

/**
 * Marca uma posição do tabuleiro com a peça do jogador e retorna o tabuleiro.
 */
tTabuleiro MarcaPosicaoTabuleiro(tTabuleiro tabuleiro, int peca, int x, int y)
{
    if (peca == PECA_1)
        tabuleiro.posicoes[y][x] = tabuleiro.peca1;
    else if (peca == PECA_2)
        tabuleiro.posicoes[y][x] = tabuleiro.peca2;

    return tabuleiro;
}

/**
 * Verifica se há alguma posição livre no tabuleiro.
 */
int TemPosicaoLivreTabuleiro(tTabuleiro tabuleiro)
{
    for (int i = 0; i < TAM_TABULEIRO; i++)
    {
        for (int j = 0; j < TAM_TABULEIRO; j++)
        {
            if (tabuleiro.posicoes[i][j] == tabuleiro.pecaVazio)
            {
                return 1;
            }
        }
    }
    return 0;
}

/**
 * Verifica se a posição do tabuleiro está marcada com a peça do jogador.
 */
int EstaMarcadaPosicaoPecaTabuleiro(tTabuleiro tabuleiro, int x, int y, int peca)
{
    if (peca == PECA_1)
        return tabuleiro.posicoes[y][x] == tabuleiro.peca1;

    if (peca == PECA_2)
        return tabuleiro.posicoes[y][x] == tabuleiro.peca2;

    return 0;
}

/**
 * Verifica se a posição do tabuleiro está livre.
 */
int EstaLivrePosicaoTabuleiro(tTabuleiro tabuleiro, int x, int y)
{
    return tabuleiro.posicoes[y][x] == tabuleiro.pecaVazio;
}

/**
 * Verifica se a posição do tabuleiro é válida.
 */
int EhPosicaoValidaTabuleiro(int x, int y)
{
    return (x >= 0 && x < TAM_TABULEIRO && y >= 0 && y < TAM_TABULEIRO);
}

/**
 * Verifica se o tabuleiro está cheio.
 */
void ImprimeTabuleiro(tTabuleiro tabuleiro)
{
    for (int i = 0; i < TAM_TABULEIRO; i++)
    {    
        for (int j = 0; j < TAM_TABULEIRO; j++)
        {  if(j==0){
            printf("    ");
        }
            printf("%c",tabuleiro.posicoes[i][j]);
        }
        printf("\n");
    }
}