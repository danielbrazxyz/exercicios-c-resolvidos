// feito por - daniel braz 26/08/26
#include <stdio.h>
#include "ponto.h"
int main(){
float x,y,x2,y2;
scanf("%f %f %f %f",&x,&y,&x2,&y2);

Ponto p1 = pto_cria(x,y);
Ponto p2 = pto_cria(x2,y2);

float dist = pto_distancia(p1,p2);
printf("%g",dist);
}